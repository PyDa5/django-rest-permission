# -*- coding: utf-8 -*-

# 缓存权限键样式
DEFUALT_USER_PERMISSIONS_CACHE_KEY_PATTERN = 'drp_user:permissions:{user_id}'
