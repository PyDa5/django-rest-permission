from django.apps import AppConfig


class DrfPermConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_rest_permission'
